import xbmcaddon

MainBase = 'http://bit.ly/2fIAUlj'
addon = xbmcaddon.Addon('plugin.video.tugak')