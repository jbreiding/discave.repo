import xbmcaddon

MainBase = 'http://www.warez-box.com/KodiBox/KodiBox/home.txt'
addon = xbmcaddon.Addon('plugin.video.KodiBox')