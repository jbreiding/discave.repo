import xbmcaddon
import base64

MainBase = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL1RlYW1ibHVlMTk2NS9NRU5VUy9tYXN0ZXIvTUVOVV9QUklOQ0lQQUw='.decode('base64')
addon = xbmcaddon.Addon('plugin.video.teamblue')