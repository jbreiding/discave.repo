import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/Teamblue1965/MENUS/master/MENU_PRINCIPAL'
addon = xbmcaddon.Addon('plugin.video.teamblue')