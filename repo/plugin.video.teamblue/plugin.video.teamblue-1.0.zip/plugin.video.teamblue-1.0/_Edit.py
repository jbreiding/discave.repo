import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/Teamblue65/Kodi-plugin-video/master/plugin.video.teamblue'
addon = xbmcaddon.Addon('plugin.video.teamblue')